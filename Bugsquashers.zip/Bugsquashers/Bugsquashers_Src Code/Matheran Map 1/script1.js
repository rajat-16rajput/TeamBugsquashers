function initMap()
{
   map = new google.maps.Map(document.getElementById('map'), {
  center: {lat: 18.99279688393996, lng: 73.2777118652341},
  zoom: 15,
  mapId: '97412f0fd4f03712'
});
}

